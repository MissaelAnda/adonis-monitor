<script lang="ts" setup>


const { entries } = defineProps<{
  entries: Entry<'request'>,
}>()
</script>

<template>
  <div>
    <div v-for="(entry, id) in entries" :key="id">{ entry.request.url }</div>
  </div>
</template>
