// import { configProvider } from "@adonisjs/core";
// import { ConfigProvider } from "@adonisjs/core/types";
import { MonitorConfig } from "./types.js";

// TODO: use configProvider
export function defineConfig(
  config: MonitorConfig,
): MonitorConfig {
  return config
}
