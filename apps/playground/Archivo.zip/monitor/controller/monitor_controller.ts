import type { HttpContext } from '@adonisjs/core/http'
import monitor from '../service/main.js'
import { isPromise } from 'util/types'

export default class MonitorController {
  async handle({ request, response, inertia }: HttpContext) {
    const resource = request.param('resource')
    if (resource == null) {
      return response.redirect('/monitor/requests')
    }

    const entry = request.param('entry')
    const view = resource + '/' + (entry ? 'entry' : 'index')

    let pagination = entry ? undefined : monitor.getStore().get(resource)

    if (isPromise(pagination)) {
      pagination = await pagination
    }

    return inertia.render(view, {
      entry,
      pagination,
    })
  }
}