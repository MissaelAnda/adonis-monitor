/// <reference path="./types.d.ts" />

import { MiddlewareFn, OneOrMore, ParsedNamedMiddleware } from "@adonisjs/core/types/http"
import Monitor from "./monitors/base.js"
import { DateTime } from "luxon"
import { Payloads } from "adonis-monitor"
import { Configurations } from "adonis-monitor"
import { UUID } from "node:crypto"

export type Monitors = Record<string, Monitor<EntryType>>

// ----------
// Entries
// ----------

export type EntryType = keyof Payloads
export type EntryFilterFn<Type extends EntryType> = (entry: Entry<Type>) => boolean | null | undefined | void
// TODO: allow transformer to add values but not change them
// export type EntryTransformerFn<Type extends EntryType, NewPayload extends Payloads[Type]> = (entry: Entry<Type>) => NewPayload
export type EntryTransformerFn<Type extends EntryType> = (payload: Payloads[Type]) => Payloads[Type]


export type AuthData = { id: string | number, guard: string }
export type Payload<Type extends EntryType> = Payloads[Type] & { auth?: Partial<AuthData> }

export type Entry<Type extends EntryType> = {
  id: UUID,
  type: Type,
  ts: DateTime,
  payload: Payload<Type>,
}

// ----------
// Config
// ----------
export type Constructor<T> = new (...args: any[]) => T;
type LazyMonitorImporter<Type extends EntryType> = () => Promise<{ default: Constructor<Monitor<Type>> }>
type MonitorRegister<Type extends EntryType> = Monitor<Type> | LazyMonitorImporter<Type> | typeof Monitor
type MonitorRegisterWithConfig<Type extends EntryType> = [MonitorRegister<Type>, Configurations[Type]]
export type MonitorBaseConfig<Type extends EntryType> = {
  enabled: boolean,
  filters: EntryFilterFn<Type>[],
  transformers: EntryTransformerFn<Type>[],
}

export type DefinableBaseConfig<Type extends EntryType> = Partial<MonitorBaseConfig<Type>>

export type MonitorConfig = {
  enabled: boolean;
  route?: {
    name?: string | null;
    path?: string | null;
    middleware?: OneOrMore<MiddlewareFn | ParsedNamedMiddleware> | [];
  }
  monitors: (MonitorRegister<EntryType> | MonitorRegisterWithConfig<EntryType>)[];
};
