export default class ServerStarted {
  handle(payload: { port: number, host: string, duration: [number, number] }) {
    const a = 'a'
  }
}